# Flipclip

Eine statische, responsive Landingpage für Flipclip – Tricks für Trampolin und Boden.

## Veröffentlichung mit GitHub Pages
1. Erstelle ein GitHub-Repository.
2. Lade `index.html` und `style.css` hoch.
3. In **Settings → Pages** bei **Build and deployment** `Deploy from a branch` wählen, `main` und `/ (root)` auswählen und speichern.
4. GitHub veröffentlicht die Seite anschließend unter einer GitHub-Pages-Adresse. Änderungen können einige Minuten benötigen.

Die Seite enthält keine KI-Trickgenerierung und keine Fotografie.
